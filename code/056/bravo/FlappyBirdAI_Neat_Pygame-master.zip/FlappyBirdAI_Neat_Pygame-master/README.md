# FlappyBirdAI_Neat_Pygame
Here is an implemtation of Neural Networks on a Flappy Bird Game with the usage of NEAT. Simulation achieved with pygame.
This Model implements this simulation through pygame. Its fairly simple to implement simulations in pygame.
For the Learning of AI implementation of Feed Forward Neural network is achieved through NEAT Module in Python 
Be sure to download the config file, since it is very important in the implementation  through AI

For further info about NEAT go to : https://neat-python.readthedocs.io/en/latest/
